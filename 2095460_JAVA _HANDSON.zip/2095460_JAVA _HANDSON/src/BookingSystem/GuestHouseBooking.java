package BookingSystem;

public class GuestHouseBooking {
	public interface GuestHousebooking {
	     public int roomSelection();
	     public void roomAvalibility();
	     public void checkInputDate();
	     public void selection();

}
}