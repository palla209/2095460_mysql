use mysql_db2;
select sinfo.student_name, sinfo.reg_number, sresult.gpa from student_info as sinfo
inner join student_result as sresult on sresult.Reg_Number = sinfo.reg_number
 order by sresult.gpa desc;

select * from student_info order by student_name asc;

select * from student_info order by datediff(date_of_joining, date_of_birth) asc;

select sinfo.reg_number, sinfo.student_name, semester, gpa from student_info as sinfo
inner join student_result as sresult on sresult.Reg_Number = sinfo.reg_number
order by sresult.gpa desc;

select reg_number, gpa from student_result
order by Is_Eligible_Scholarship desc;

select reg_number, gpa from student_result order by Is_Eligible_Scholarship desc;

select * from student_info as sinfo
inner join student_result as sresult on sresult.reg_number = sinfo.reg_number
where sresult.gpa in (select  max(gpa) from student_result group by semester);

select * from student_info as sinfo
inner join student_result as sresult on sresult.reg_number = sinfo.reg_number
where sresult.gpa in (select  min(gpa) from student_result group by semester);